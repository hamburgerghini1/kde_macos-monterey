from conan.tools.qbs.qbsprofile import QbsProfile
from conan.tools.qbs.qbsprofile import QbsProfile as QbsToolchain
from conan.tools.qbs.qbs import Qbs
