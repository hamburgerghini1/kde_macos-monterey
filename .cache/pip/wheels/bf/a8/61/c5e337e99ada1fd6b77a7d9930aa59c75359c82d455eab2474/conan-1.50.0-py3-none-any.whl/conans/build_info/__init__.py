"""Module for extract the JFrog Artifactory Build Info JSON from a conan tracer log:
   https://github.com/JFrogDev/build-info"""
